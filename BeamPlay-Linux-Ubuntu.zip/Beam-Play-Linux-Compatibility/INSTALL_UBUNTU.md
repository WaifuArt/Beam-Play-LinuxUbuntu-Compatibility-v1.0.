# Quick install — Ubuntu

1. Install the required packages:

   ```bash
   sudo apt update
   sudo apt install python3 playerctl
   ```

2. Extract the Beam Play Linux Compatibility release ZIP.
3. Open a terminal in the extracted folder.
4. Run:

   ```bash
   chmod +x install_beam_play_helper.sh
   ./install_beam_play_helper.sh
   ```

5. Open Spotify and BeamNG.drive. Launch **Beam Play Helper** from the Ubuntu application menu.

If Spotify is not detected, run `playerctl -l` while Spotify is open. If the installed helper needs updating, replace the file in `~/.local/share/BeamNG/BeamNG.drive/current/settings/beamplay/` and restart it.
