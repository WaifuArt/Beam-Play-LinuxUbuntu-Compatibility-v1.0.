#!/usr/bin/env python3
"""Linux Spotify bridge for the Beam Play BeamNG mod.

Uses playerctl/MPRIS. It intentionally does not implement Windows Phone Link.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen

def run(args, timeout=3):
    try:
        p = subprocess.run(args, text=True, stdout=subprocess.PIPE,
                           stderr=subprocess.DEVNULL, timeout=timeout)
        return p.stdout.strip() if p.returncode == 0 else None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None

def choose_player():
    players = run(["playerctl", "-l"])
    if not players:
        return None
    names = [x.strip() for x in players.splitlines() if x.strip()]
    return next((x for x in names if "spotify" in x.lower()), None)

def player_call(player, *args):
    if not player:
        return None
    return run(["playerctl", "-p", player, *args])

def media_state(player, cover_dir, once=False):
    now = int(time.time())
    if not player:
        return {"updated": now, "running": False, "playing": False}

    status = player_call(player, "status") or ""
    title = player_call(player, "metadata", "title") or ""
    artist = player_call(player, "metadata", "artist") or ""
    album = player_call(player, "metadata", "album") or ""
    art_url = player_call(player, "metadata", "mpris:artUrl") or ""
    length_raw = player_call(player, "metadata", "mpris:length") or "0"
    pos_raw = player_call(player, "position") or "0"

    try:
        duration = max(0, int(float(length_raw) / 1000))  # MPRIS length is microseconds
    except ValueError:
        duration = 0
    try:
        position = max(0, int(float(pos_raw) * 1000))  # playerctl position is seconds
    except ValueError:
        position = 0
    if duration:
        position = min(position, duration)

    cover = None
    if art_url and not once:
        parsed = urlparse(art_url)
        key = art_url or f"{artist}|{album}|{title}"
        digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:12]
        cover_dir.mkdir(parents=True, exist_ok=True)

        # Spotify's Linux MPRIS sometimes exposes open.spotify.com/image URLs.
        # Those URLs may not serve the raw image; i.scdn.co is the image CDN.
        candidates = [art_url]
        if parsed.scheme in ("http", "https") and parsed.netloc.lower() == "open.spotify.com":
            path_part = parsed.path
            if path_part.startswith("/image/"):
                candidates.insert(0, "https://i.scdn.co" + path_part)

        for candidate in candidates:
            try:
                if candidate.startswith("file://"):
                    source = Path(unquote(urlparse(candidate).path))
                    if not source.is_file():
                        continue
                    raw = source.read_bytes()
                    content_type = ""
                elif urlparse(candidate).scheme in ("http", "https"):
                    request = Request(candidate, headers={"User-Agent": "BeamPlayLinux/1.1"})
                    with urlopen(request, timeout=8) as response:
                        raw = response.read(12 * 1024 * 1024 + 1)
                        content_type = response.headers.get("Content-Type", "").lower()
                    if len(raw) > 12 * 1024 * 1024:
                        continue
                else:
                    continue

                # Determine extension from the actual image bytes, not just the URL.
                if raw.startswith(b"\xff\xd8\xff"):
                    ext = ".jpg"
                elif raw.startswith(b"\x89PNG\r\n\x1a\n"):
                    ext = ".png"
                elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
                    ext = ".webp"
                elif raw.startswith((b"GIF87a", b"GIF89a")):
                    ext = ".gif"
                else:
                    continue

                target = cover_dir / f"cover_{digest}{ext}"
                if not target.exists():
                    target.write_bytes(raw)
                cover = f"temp/beamplay/cover_{digest}{ext}"
                break
            except (OSError, ValueError):
                continue

    shuffle_raw = player_call(player, "shuffle")
    loop_raw = player_call(player, "loop")
    return {
        "updated": now,
        "running": True,
        "playing": status.lower() == "playing",
        "title": title,
        "artist": artist,
        "album": album,
        "position": position,
        "duration": duration,
        "shuffle": str(shuffle_raw).lower() in ("on", "true", "1"),
        "repeat": str(loop_raw).lower() not in ("none", "off", "false", ""),
        "cover": cover,
    }

def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    os.replace(tmp, path)

def process_command(cmd_file, player):
    global last_seq
    if not cmd_file.exists():
        return
    try:
        data = json.loads(cmd_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return
    seq = data.get("seq")
    if seq is None:
        return
    if last_seq is None:
        last_seq = seq
        return
    if seq == last_seq:
        return
    last_seq = seq
    command = str(data.get("cmd", ""))
    actions = {
        "play": ["play-pause"],
        "next": ["next"],
        "prev": ["previous"],
        "shuffle": ["shuffle", "Toggle"],
        "repeat": ["loop", "None"],
    }
    if command == "open_spotify":
        subprocess.Popen(["spotify"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif command == "seek":
        try:
            seconds = float(data.get("arg", 0)) / 1000.0
            player_call(player, "position", str(max(0, seconds)))
        except (TypeError, ValueError):
            pass
    elif command in actions and player:
        player_call(player, *actions[command])

last_seq = None
def main():
    parser = argparse.ArgumentParser(description="Beam Play Linux Spotify bridge")
    parser.add_argument("--user-folder", default="")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--read-only", action="store_true")
    parser.add_argument("--no-phone", action="store_true")
    parser.add_argument("--interval-ms", type=int, default=500)
    parser.add_argument("--with-game", action="store_true")
    parser.add_argument("--watch", action="store_true")
    args = parser.parse_args()

    home = Path.home()
    base = home / ".local/share/BeamNG/BeamNG.drive"
    if args.user_folder:
        user_folder = Path(args.user_folder).expanduser()
    elif (base / "current").exists():
        user_folder = base / "current"
    else:
        versions = sorted([p for p in base.iterdir()] if base.exists() else [],
                          key=lambda p: p.name, reverse=True)
        versions = [p for p in versions if p.is_dir() and p.name[:1].isdigit()]
        if not versions:
            print(f"BeamNG user folder not found. Expected {base}/current or a version folder.", file=sys.stderr)
            return 2
        user_folder = versions[0]

    data_dir = user_folder / "settings/beamplay"
    cover_dir = user_folder / "temp/beamplay"
    now_file = data_dir / "now_playing.json"
    cmd_file = data_dir / "command.json"
    phone_file = data_dir / "phone.json"

    if shutil.which("playerctl") is None:
        print("Missing dependency: playerctl. Install it with: sudo apt install playerctl", file=sys.stderr)
        return 2

    if args.once:
        player = choose_player()
        print(json.dumps(media_state(player, cover_dir, once=True), ensure_ascii=False))
        if not args.no_phone:
            print("Phone Link features are Windows-only and are not available in this Linux bridge.")
        return 0

    print(f"Beam Play Linux bridge running. Writing {now_file}")
    print("Press Ctrl+C to stop. Open Spotify on this computer.")
    seen_game = False
    wait_start = time.monotonic()
    last_line = None
    try:
        while True:
            game_running = True
            if args.with_game or args.watch:
                game_running = subprocess.run(
                    ["pgrep", "-f", "BeamNG\\.drive\\.x64|BeamNG\\.x64|BeamNG\\.drive"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                ).returncode == 0
                if not game_running:
                    if args.with_game and (seen_game or time.monotonic() - wait_start > 300):
                        print("BeamNG closed/not started - bridge exiting")
                        break
                    if seen_game:
                        print("BeamNG closed - waiting for it")
                        seen_game = False
                    time.sleep(3)
                    continue
                if not seen_game:
                    print("BeamNG running - bridge active")
                    seen_game = True

            player = choose_player()
            try:
                if not args.read_only:
                    process_command(cmd_file, player)
                state = media_state(player, cover_dir)
                write_json(now_file, state)
                if not args.no_phone:
                    write_json(phone_file, {
                        "updated": int(time.time()),
                        "phonelink": {"installed": False, "running": False, "notificationAccess": "unsupported on Linux"},
                        "device": None, "call": None, "notifications": [],
                        "contacts": [], "recents": [], "lastAction": {
                            "ok": False, "msg": "Phone Link is Windows-only"
                        }
                    })
                if not state.get("running"):
                    line = "Bridge running - waiting for Spotify (open Spotify on this PC)"
                elif state.get("title"):
                    line = f"{'Playing' if state.get('playing') else 'Paused'}: {state.get('artist', '')} - {state.get('title', '')}"
                else:
                    line = "Spotify open - nothing playing"
                if line != last_line:
                    print(time.strftime("[%H:%M:%S] ") + line, flush=True)
                    last_line = line
            except Exception as exc:
                print(f"warning: {exc}", file=sys.stderr, flush=True)
            time.sleep(max(100, args.interval_ms) / 1000)
    except KeyboardInterrupt:
        print("\nBeam Play Linux bridge stopped.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
