#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BRIDGE="$HERE/beamplay_spotify_bridge.py"
BASE="$HOME/.local/share/BeamNG/BeamNG.drive"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install it with: sudo apt install python3"
  exit 1
fi
if ! command -v playerctl >/dev/null 2>&1; then
  echo "playerctl is required. Install it with: sudo apt install playerctl"
  exit 1
fi

if [[ -d "$BASE/current" ]]; then
  USER_FOLDER="$BASE/current"
else
  USER_FOLDER="$(find "$BASE" -mindepth 1 -maxdepth 1 -type d -printf '%f\\n' 2>/dev/null | grep -E '^[0-9]+\\.[0-9]+' | sort -V | tail -n 1 || true)"
  if [[ -z "$USER_FOLDER" ]]; then
    echo "Could not find a BeamNG user folder under: $BASE"
    echo "Open BeamNG once, then run this installer again."
    exit 1
  fi
  USER_FOLDER="$BASE/$USER_FOLDER"
fi

DEST="$USER_FOLDER/settings/beamplay"
APP_DIR="$HOME/.local/share/applications"
mkdir -p "$DEST" "$APP_DIR"
install -m 755 "$BRIDGE" "$DEST/beamplay_spotify_bridge.py"

cat > "$APP_DIR/beam-play-helper.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Beam Play Helper
Comment=BeamNG Spotify bridge
Exec=python3 "$DEST/beamplay_spotify_bridge.py" --with-game
Terminal=true
Categories=Game;AudioVideo;
EOF
chmod 644 "$APP_DIR/beam-play-helper.desktop"

echo
echo "Beam Play Linux bridge installed to:"
echo "  $DEST"
echo
echo "You can launch 'Beam Play Helper' from your application menu."
echo "Or run it manually:"
echo "  python3 \"$DEST/beamplay_spotify_bridge.py\" --with-game"
echo
echo "Dependency: sudo apt install playerctl"
echo "Your BeamNG installation and existing mod files were not modified."
