# Beam Play — Linux Compatibility

An **unofficial community Linux compatibility helper** for the Beam Play mod for [BeamNG.drive](https://www.beamng.com/).

**Original Beam Play mod owner: TorqueDistrict.** This project is a community-made Linux bridge; it is not an official TorqueDistrict release and is not affiliated with or endorsed by TorqueDistrict unless they say otherwise.

## What it does

The helper connects Beam Play to Spotify on Linux using MPRIS via `playerctl` and writes the playback state expected by the Beam Play UI.

- Spotify playback state (playing/paused)
- Track title, artist, and album
- Playback position and duration
- Shuffle and repeat state
- Play/pause, next, previous, shuffle, repeat, and seek commands
- Album artwork from local image files and supported HTTPS image URLs
- Optional wait/monitor behavior for BeamNG.drive

## Not currently supported

Windows Phone Link features are Windows-specific and are not implemented by this Linux helper. This includes phone notifications, contacts, and call integration. The bridge writes a minimal unsupported status for the Phone Link portion of the UI.

## Requirements

- Ubuntu or another Linux desktop distribution
- Python 3
- `playerctl`
- BeamNG.drive installed and launched at least once
- The original Beam Play mod installed, with its UI/Lua side supporting the expected `settings/beamplay` JSON files
- Spotify running in the same desktop login session and exposing an MPRIS player

Install the dependency on Ubuntu:

```bash
sudo apt update
sudo apt install python3 playerctl
```

## Installation

1. Download and extract this repository (or the release ZIP).
2. Open a terminal in the extracted folder.
3. Run:

   ```bash
   chmod +x install_beam_play_helper.sh
   ./install_beam_play_helper.sh
   ```

4. Launch **Beam Play Helper** from the desktop application menu, or run it manually:

   ```bash
   python3 ~/.local/share/BeamNG/BeamNG.drive/current/settings/beamplay/beamplay_spotify_bridge.py --with-game
   ```

The installer detects `BeamNG.drive/current` or the newest versioned BeamNG user folder and installs the bridge into that folder's `settings/beamplay` directory. It also creates a desktop application-menu entry.

If your BeamNG user folder is not detected automatically, install the script manually into the correct user folder's `settings/beamplay` directory and use `--user-folder "/full/path/to/BeamNG user folder"`.

## Verify Spotify is visible

With Spotify open, run:

```bash
playerctl -l
playerctl -p spotify status
playerctl -p spotify metadata mpris:artUrl
```

If `playerctl -l` does not list Spotify, the bridge cannot read Spotify until the desktop session exposes its MPRIS interface. Spotify packaging (Snap, Flatpak, or native package) and desktop-session configuration can affect this.

## Troubleshooting

### The bridge says `playerctl` is missing

```bash
sudo apt install playerctl
```

### Spotify is not detected

Open Spotify and check `playerctl -l`. The bridge needs Spotify's MPRIS player to be visible in the same logged-in desktop session.

### Album artwork is missing

Check the artwork URL:

```bash
playerctl -p spotify metadata mpris:artUrl
```

Then check the bridge output file and downloaded images:

```bash
cat ~/.local/share/BeamNG/BeamNG.drive/current/settings/beamplay/now_playing.json
ls -lh ~/.local/share/BeamNG/BeamNG.drive/current/temp/beamplay/
```

A `null` value for `cover` means the bridge did not save an image for that track. Some Spotify artwork URLs may be unavailable; the helper can only display artwork that it can successfully retrieve.

### Beam Play still shows its placeholder

Make sure the **installed** bridge is the updated one. The extracted download folder is not the live installation. The running script should be:

`~/.local/share/BeamNG/BeamNG.drive/current/settings/beamplay/beamplay_spotify_bridge.py`

If replacing it manually, copy the new file into that exact directory and restart the bridge.

## Run options

```bash
# Wait for BeamNG and exit after the game closes / timeout
python3 beamplay_spotify_bridge.py --with-game

# Run continuously, independent of game process detection
python3 beamplay_spotify_bridge.py

# Print a one-time status sample
python3 beamplay_spotify_bridge.py --once

# Specify a BeamNG user folder explicitly
python3 beamplay_spotify_bridge.py --user-folder "/path/to/BeamNG.drive/user/folder"
```

Stop a running bridge with `Ctrl+C`.

## Files and safety

The helper installs only its bridge script and a desktop launcher. It does not replace BeamNG executables or modify the original Beam Play mod files. It writes runtime JSON and cached artwork under the selected BeamNG user folder (`settings/beamplay` and `temp/beamplay`).

## Credits and project status

- **Original Beam Play mod:** TorqueDistrict
- **Linux compatibility helper:** community adaptation maintained by contributors to this repository
- **Tested setup:** Ubuntu desktop, BeamNG.drive Linux build, Spotify with MPRIS, `playerctl`

This repository does not include TorqueDistrict's original mod assets or claim ownership of Beam Play. Users must obtain and install the original mod separately and follow its own terms.

## License

No open-source license has been selected for this repository yet. Until a license is added, do not assume that the code may be redistributed, modified, or incorporated into other projects beyond the permissions granted by applicable law. The original Beam Play mod remains the property of its respective owner, TorqueDistrict.
