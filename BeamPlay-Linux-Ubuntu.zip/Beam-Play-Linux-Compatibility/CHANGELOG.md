# Changelog

## v1.0.0 — Community release preparation

- Linux Spotify bridge using `playerctl` / MPRIS.
- Playback metadata and transport controls.
- Album artwork retrieval from local files and supported HTTPS URLs.
- Ubuntu installer and desktop application-menu launcher.
- Documentation for installation, limitations, and troubleshooting.

This release is based on the v3 bridge that was tested with multiple Spotify tracks on an Ubuntu desktop with BeamNG.drive.
